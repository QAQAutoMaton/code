#include <cstdio>
#include <vector>
#include <iostream>

using namespace std;

const int MAXN = 200005;

inline int read() {
  int x = 0, f = 1; char ch = getchar();
  while(!isdigit(ch)) { 
    if(ch == '-') f = -1;
    ch = getchar();
  }
  while(isdigit(ch)) { 
    x = x * 10 + ch - '0';
    ch = getchar(); 
  }
  return x * f;
}

vector<int> G1[MAXN][15];
vector<int> G2[MAXN][15];

int n, k, m, vis1[MAXN][15], vis2[MAXN][15];

void dfs1(int cur, int c) {
  for(auto nx: G1[cur][c]) {
    if(!vis1[nx][c]) {
      vis1[nx][c] = 1;
      dfs1(nx, c);
    }
  }
}

void dfs2(int cur, int c) {
  for(auto nx: G2[cur][c]) {
    if(!vis2[nx][c]) {
      vis2[nx][c] = 1;
      dfs2(nx, c);
    }
  }
}

int main() {
  n = read(), k = read(), m = read();
  for(int i = 1; i <= m; i++) {
    int x = read(), y = read(), z = read();
    G1[x][z].push_back(y);
    G2[y][z].push_back(x);
  }

  for(int i = 1; i <= k; i++) {
    dfs1(1, i); dfs2(1, i);
  }

  int cnt1 = 0, cnt2 = 0;

  for(int i = 2; i <= n; i++) {
    bool ok1 = true, ok2 = true;
    for(int j = 1; j <= k; j++) {
      if(!vis1[i][j]) ok1 = false;
      if(!vis2[i][j]) ok2 = false;
    }
    if(ok1) cnt1++;
    if(ok2) cnt2++;
  }

  printf("%d %d\n", n - cnt1, cnt2 + 1);
  // cerr << cnt1 << " " << cnt2 << endl;
  return 0;
}