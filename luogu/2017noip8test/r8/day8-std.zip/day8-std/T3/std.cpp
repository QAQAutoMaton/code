#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>

using namespace std;

const int MAXN = 200005;

typedef long long ll;

inline int read() {
  int x = 0, f = 1; char ch = getchar();
  while(!isdigit(ch)) { 
    if(ch == '-') f = -1;
    ch = getchar();
  }
  while(isdigit(ch)) { 
    x = x * 10 + ch - '0';
    ch = getchar(); 
  }
  return x * f;
}

int n, a, b, c, tot, l[MAXN], r[MAXN], disp[MAXN], dp[MAXN];

vector<int> p1[MAXN], p2[MAXN];

struct Node {
  int val, tag;
  Node *ls, *rs;
  Node(): val(0), tag(0), ls(nullptr), rs(nullptr) { }
  void update(int t) {
    val += t;
    tag += t;
  }
  void pushup() {
    val = max(ls->val, rs->val);
  }
  void pushdown() {
    if(tag) {
      ls->update(tag);
      rs->update(tag);
      tag = 0;
    }
  }
}pool[MAXN<<3];

int segNode;

Node *newNode() {
  return &pool[segNode++];
}

Node *build(int l, int r) {
  Node *cur = newNode();
  if(l < r) {
    int mid = (l + r) / 2;
    cur->ls = build(l, mid);
    cur->rs = build(mid + 1, r);
    cur->pushup();
  }
  return cur;
}

void add(Node *cur, int l, int r, int a, int b, int v) {
  if(a <= l && b >= r) {
    cur->update(v);
  } else {
    cur->pushdown();
    int mid = (l + r) / 2;
    if(a <= mid) add(cur->ls, l, mid, a, b, v);
    if(b > mid) add(cur->rs, mid + 1, r, a, b, v);
    cur->pushup();
  }
}

int query(Node *cur, int l, int r, int a, int b) {
  if(a > b) return -1e9;
  if(a <= l && b >= r) return cur->val;
  cur->pushdown();
  int mid = (l + r) / 2, res = 0;
  if(a <= mid) res = max(res, query(cur->ls, l, mid, a, b));
  if(b > mid) res = max(res, query(cur->rs, mid + 1, r, a, b));
  return res;
}

int f(int x) {
  if(x <= a) return 2 * x - c;
  if(x < b) return x + a - c;
  if(x >= b) return a + b - c;
}

int dfs(Node *cur, int l, int r, int x) {
  if(l == r) return l;
  int mid = (l + r) / 2;
  cur->pushdown();
  if(cur->rs->val > x) return dfs(cur->rs, mid + 1, r, x);
  else if(cur->ls->val > x) return dfs(cur->ls, l, mid, x);
  else return -1;
}

int find(Node *root, int x) {
  return dfs(root, 0, tot, x);
}

int main() {
  n = read(), a = read(), b = read(), c = read();
  for(int i = 1; i <= n; i++) {
    l[i] = read(), r[i] = read();
    disp[++tot] = l[i];
    disp[++tot] = r[i];
  }
  sort(disp + 1, disp + tot + 1);
  tot = unique(disp + 1, disp + tot + 1) - disp - 1;
  for(int i = 1; i <= n; i++) {
    l[i] = lower_bound(disp + 1, disp + tot + 1, l[i]) - disp;
    r[i] = lower_bound(disp + 1, disp + tot + 1, r[i]) - disp;
    p1[l[i]].push_back(r[i]);
    p2[r[i]].push_back(l[i]);
  }
  Node *root1 = build(0, tot); // dp[i] + cnt
  Node *root2 = build(0, tot); // dp[i] + 2 * cnt
  Node *root3 = build(0, tot); // cnt
  Node *root4 = build(0, tot); // dp[i]
  int ans = 0;
  for(int i = 1; i <= tot; i++) {
    for(auto L: p2[i - 1]) {
      add(root1, 0, tot, 0, L - 1, -1);
      add(root2, 0, tot, 0, L - 1, -2);
      add(root3, 0, tot, 0, L - 1, -1);
    }
    for(auto R: p1[i]) {
      add(root1, 0, tot, 0, i - 1, 1);
      add(root2, 0, tot, 0, i - 1, 2);
      add(root3, 0, tot, 0, i - 1, 1);
    }
    int x1 = find(root3, a); 
    int x2 = find(root3, b); 
    dp[i] = max(dp[i], query(root2, 0, tot, x1 + 1, i - 1) - c);
    dp[i] = max(dp[i], query(root1, 0, tot, x2 + 1, x1) + a - c);
    dp[i] = max(dp[i], query(root4, 0, tot, 0, x2) + a + b - c);
    add(root1, 0, tot, i, i, dp[i]);
    add(root2, 0, tot, i, i, dp[i]);
    add(root4, 0, tot, i, i, dp[i]);
    ans = max(ans, dp[i]);
  }
  printf("%d\n", ans);
  return 0;
}