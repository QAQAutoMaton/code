#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>

using namespace std;

const int MAXN = 200005;

inline int read() {
  int x = 0, f = 1; char ch = getchar();
  while(!isdigit(ch)) { 
    if(ch == '-') f = -1;
    ch = getchar();
  }
  while(isdigit(ch)) { 
    x = x * 10 + ch - '0';
    ch = getchar(); 
  }
  return x * f;
}

int n, a, b, c, tot, l[MAXN], r[MAXN], disp[MAXN], dp[MAXN];

vector<int> p[MAXN];

int f(int x) {
  if(x <= a) return 2 * x - c;
  if(x < b) return x + a - c;
  if(x >= b) return a + b - c;
}

int main() {
  n = read(), a = read(), b = read(), c = read();
  for(int i = 1; i <= n; i++) {
    l[i] = read(), r[i] = read();
    disp[++tot] = l[i];
    disp[++tot] = r[i];
  }
  sort(disp + 1, disp + tot + 1);
  tot = unique(disp + 1, disp + tot + 1) - disp - 1;
  for(int i = 1; i <= n; i++) {
    l[i] = lower_bound(disp + 1, disp + tot + 1, l[i]) - disp;
    r[i] = lower_bound(disp + 1, disp + tot + 1, r[i]) - disp;
    p[l[i]].push_back(r[i]);
  }
  int ans = 0;
  for(int i = 1; i <= tot; i++) {
    int now = 0;
    for(int j = i - 1; j >= 0; j--) {
      for(auto cur: p[j + 1]) {
        if(cur >= i) now++;
      }
      dp[i] = max(dp[i], dp[j] + f(now));
    }
    ans = max(ans, dp[i]);
    // printf("dp[%d] = %d\n", i, dp[i]);
  }
  printf("%d\n", ans);
  return 0;
}