#include <cstdio>
#include <iostream>

using namespace std;

typedef long long ll;
typedef __int128 lll;

int main() {
  ll n, k;
  cin >> n >> k;
  for(ll x = 1; ; x++) {
    lll a = (lll)(x + 1) * (lll)(n + x - k);
    lll b = (lll)x * (lll)(n + x);
    if(a <= b) {
      cout << x - 1 << endl;
      return 0;
    }
  }
  return 0;
}