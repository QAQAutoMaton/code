#include <cstdio>
#include <iostream>

using namespace std;

typedef long long ll;

ll n, k;

ll g(ll x) {
  return (1 - k) * x + n + 1 - 2 * k;
}

int main() {
  cin >> n >> k;
  ll x = (n + 1 - 2 * k) / (k - 1);
  while(g(x) > 0) x++;
  cout << x << endl;
  return 0;
}