#include"bits/stdc++.h"


#define PB push_back
#define PF push_front
#define LB lower_bound
#define UB upper_bound
#define fr(x) freopen(x,"r",stdin)
#define fw(x) freopen(x,"w",stdout)
#define iout(x) printf("%d\n",x)
#define lout(x) printf("%lld\n",x)
#define REP(x,l,u) for(int x = (l);x<=(u);++x)
#define RREP(x,l,u) for(int x = (l);x>=(u);--x)
#define mst(x,a) memset(x,a,sizeof(x))
#define PII pair<int,int>
#define PLL pair<ll,ll>
#define MP make_pair
#define se second
#define fi first
#define dbg(x) cout<<#x<<" = "<<(x)<<endl;
#define sz(x) ((int)x.size())
#define cl(x) x.clear()

typedef  long long ll;
typedef unsigned long long ull;
typedef double db;
typedef long double ld;
using namespace std;

const int maxn = 300010;
const int mod = 1e9+7;
const double eps = 1e-6;
const double PI = acos(-1);

template<typename T> inline void read(T &x){
x=0;T f=1;char ch;do{ch=getchar();if(ch=='-')f=-1;}while(ch<'0'||ch>'9');do x=x*10+ch-'0',ch=getchar();while(ch<='9'&&ch>='0');x*=f;
}

template<typename A,typename B> inline void read(A&x,B&y){read(x);read(y);}
template<typename A,typename B,typename C> inline void read(A&x,B&y,C&z){read(x);read(y);read(z);}
template<typename A,typename B,typename C,typename D> inline void read(A&x,B&y,C&z,D&w){read(x);read(y);read(z);read(w);}
template<typename A,typename B> inline A fexp(A x,B p){A ans=1;for(;p;p>>=1,x=1LL*x*x%mod)if(p&1)ans=1LL*ans*x%mod;return ans;}
template<typename A,typename B> inline A fexp(A x,B p,A mo){A ans=1;for(;p;p>>=1,x=1LL*x*x%mo)if(p&1)ans=1LL*ans*x%mo;return ans;}

int n,m,blo;

int A[maxn];

int pos[maxn];

int smb[maxn];

int has[1000][1000];

int query(int l,int r){
	int ans=0;
	if(pos[l]==pos[r]){
		REP(i,l,r)ans=(ans+A[i])%mod;
		return ans;
	}
	REP(i,pos[l]+1,pos[r]-1)ans=(ans+smb[i])%mod;
	REP(i,l,min(pos[l]*blo,n))ans=(ans+A[i])%mod;
	REP(i,(pos[r]-1)*blo+1,r)ans=(ans+A[i])%mod;
	return ans;
}

void Work(){
	while(m--){
		int opt,x,y,z;read(opt,x,y);
		if(opt==1){
			read(z);
			if(x>blo){
				for(int i=y;i<=n;i+=x)A[i]=(A[i]+z)%mod,smb[pos[i]]=(smb[pos[i]]+z)%mod;
			}
			else{
				has[x][y]=(has[x][y]+z)%mod;
			}
		}
		else{ 
			int ans=query(x,y);
			REP(i,1,blo)REP(j,1,i)if(has[i][j]){
				int t=(y+i-j)/i-(x-1+i-j)/i;
				ans=(ans+1LL*t*has[i][j])%mod;
			}
			iout(ans);
		}
	}
}

void Init(){
	read(n,m);
	blo=(int)pow(n,1./3);
	cerr<<blo<<endl;
	REP(i,1,n)read(A[i]);
	REP(i,1,n)pos[i]=(i-1)/blo+1;
	REP(i,1,n)smb[pos[i]]=(smb[pos[i]]+A[i])%mod;
}

int main(){
	fr("1.in");
	fw("4.out");
	Init();
	Work();
	cerr<<clock()<<endl;
	return 0;
}

