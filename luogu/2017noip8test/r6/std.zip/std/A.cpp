#include<bits/stdc++.h>



using namespace std;
const int maxn = 1010 , maxm = 1000010;

int n,m;

char a[maxm],b[maxn];

int nxt[maxm][26],now[26],dp[maxn][maxn];

void Work(){
	for(int i=0;i<26;i++)now[i]=m+1;
	for(int i=m;i>=0;i--){
		for(int j=0;j<26;j++)nxt[i][j]=now[j];
		now[a[i]-'a']=i;
	}
	for(int i=0;i<=n;i++)for(int j=0;j<=n;j++)dp[i][j]=m+1;
	dp[0][0]=0;
	for(int i=0;i<n;i++)
		for(int j=0;j<=i;j++)if(dp[i][j]<=m){
			dp[i+1][j]=min(dp[i+1][j],dp[i][j]);
			dp[i+1][j+1]=min(dp[i+1][j+1],nxt[dp[i][j]][b[i+1]-'a']);
		}
	int ans=0;
	for(int i=0;i<=n;i++)if(dp[n][i]<=m)ans=i;
	printf("%d\n",ans);
}

void Init(){
	scanf("%s%s",a+1,b+1);
	m=strlen(a+1);n=strlen(b+1);
}

int main(){
	Init(),
	Work();
	return 0;
}
