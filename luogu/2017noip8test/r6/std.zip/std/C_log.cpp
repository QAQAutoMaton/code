#include"bits/stdc++.h"


#define PB push_back
#define PF push_front
#define LB lower_bound
#define UB upper_bound
#define fr(x) freopen(x,"r",stdin)
#define fw(x) freopen(x,"w",stdout)
#define iout(x) printf("%d\n",x)
#define lout(x) printf("%lld\n",x)
#define REP(x,l,u) for(int x = (l);x<=(u);++x)
#define RREP(x,l,u) for(int x = (l);x>=(u);--x)
#define mst(x,a) memset(x,a,sizeof(x))
#define PII pair<int,int>
#define PLL pair<ll,ll>
#define MP make_pair
#define se second
#define fi first
#define dbg(x) cout<<#x<<" = "<<(x)<<endl;
#define sz(x) ((int)x.size())
#define cl(x) x.clear()

typedef  long long ll;
typedef unsigned long long ull;
typedef double db;
typedef long double ld;
using namespace std;

const int maxn = 500010;
const int mod = 1e9+7;
const double eps = 1e-6;
const double PI = acos(-1);

template<typename T> inline void read(T &x){
x=0;T f=1;char ch;do{ch=getchar();if(ch=='-')f=-1;}while(ch<'0'||ch>'9');do x=x*10+ch-'0',ch=getchar();while(ch<='9'&&ch>='0');x*=f;
}

template<typename A,typename B> inline void read(A&x,B&y){read(x);read(y);}
template<typename A,typename B,typename C> inline void read(A&x,B&y,C&z){read(x);read(y);read(z);}
template<typename A,typename B,typename C,typename D> inline void read(A&x,B&y,C&z,D&w){read(x);read(y);read(z);read(w);}
template<typename A,typename B> inline A fexp(A x,B p){A ans=1;for(;p;p>>=1,x=1LL*x*x%mod)if(p&1)ans=1LL*ans*x%mod;return ans;}
template<typename A,typename B> inline A fexp(A x,B p,A mo){A ans=1;for(;p;p>>=1,x=1LL*x*x%mo)if(p&1)ans=1LL*ans*x%mo;return ans;}

int n,m,blo;

int A[maxn];

int c[maxn],c2[1010][1010];

void add(int x,int y){
	for(;x<=n;x+=x&-x)c[x]=(c[x]+y)%mod;
}
int query(int x){
	int ans=0;
	for(;x;x-=x&-x)ans=(ans+c[x])%mod;
	return ans;
}

void add2(int x,int y,int z){
	for(;y<=blo;y+=y&-y)c2[x][y]=(c2[x][y]+z)%mod;
}
int query2(int x,int y){
	int ans=0;
	for(;y;y-=y&-y)ans=(ans+c2[x][y])%mod;
	return ans;
}

void Work(){
	while(m--){
		int opt,x,y,z;read(opt,x,y);
		if(opt==1){
			read(z);
			if(x>blo){
				for(int i=y;i<=n;i+=x)add(i,z);
			}
			else{
				add2(x,y,z);
			}
		}
		else{ 
			int ans=(query(y)-query(x-1)+mod)%mod;
			REP(i,1,blo)if(query2(i,i)){
				int l=(x-1)%i+1,r=(y-1)%i+1;
				int t=(y+i-l)/i-(x-1+i-l)/i;
				if(l<=r){
					int t2=(query2(i,r)-query2(i,l-1)+mod)%mod;
					ans=(ans+1LL*t*t2%mod)%mod;
					ans=(ans+1LL*(t-1)*(query2(i,i)-t2+mod)%mod)%mod;
				}
				else{
					int t2=(query2(i,l-1)-query2(i,r)+mod)%mod;
					ans=(ans+1LL*(t-1)*t2%mod)%mod;
					ans=(ans+1LL*t*(query2(i,i)-t2+mod)%mod)%mod;
				}
			}
			iout(ans);
		}
	}
}

void Init(){
	read(n,m);
	blo=max(1,(int)sqrt((n+.5)/7));
	cerr<<blo<<endl;
	REP(i,1,n)read(A[i]);
	REP(i,1,n)add(i,A[i]);
}

int main(){
	fr("1.in");
	fw("5.out");
	Init();
	Work();
	cerr<<clock()<<endl;
	return 0;
}

